# hello_world
 Aprendendo sobre pacotes em Python 

Description. 
The package hello_world is used to:
	- Criado uma função, onde é chamado o Hello World na tela
	- Para aprendizado sobre pacotes em Python  

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install hello_world
```


## Author
Mauricio

## License
[MIT](https://choosealicense.com/licenses/mit/)
