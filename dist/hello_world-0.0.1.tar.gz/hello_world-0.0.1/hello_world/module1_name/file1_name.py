def ola(ola_mundo):
    print("Hello World :)")